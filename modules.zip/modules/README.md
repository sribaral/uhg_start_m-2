## Modules for BH-IAC

* This folder consists of all modules that bh uses for infra creation. 
* These modules are having their own `main.tf`, `variables.tf`, `outputs.tf`.
* Below are the Modules that are currently been developed.


## Directory Structure:
* `network/`: Contains the VPC and Subnet Configurations.
* `gke/`: Contains the GKE Configurations
* `gar/`: Containes the Google Container Registry Configurations

### Network Module
- The Network Module Setups the `Virtual Private Cloud` , `Subnets`, `Cloud Router`, `Firewalls`, and `NatGateways`
- It consists of 
    - `network.tf`: Terraform resourse code to create`network` and `subnet`
    - `nat_gateway.tf`: Consists of Terraform resource code to provision `nat gateways`
    - `router.tf`: Consists of Terraform resource code to provision `router`
    - `variables.tf`
        - Provides flexibility and reusability by parameterizing the network setup.
        - Allows dunamic configuration of subnets, routers and NAT based on the input variables.
        - These variables should be defined when calling this module in the root module 
    - `outputs.tf`:
        - Exposes the key information like VPC name, subnet names NAT IP address.
        - These are helpful when transferring inter-module communication by providing necessary outputs to other modules like `gke`
### GKE Module
- The GKE module provisions the kubernetes clustes in the specified subnets 
- It consists of:
    - `gke.tf`: Terraform resourse code to create `Google Kubernetes Engine` clusters
    - `variables.tf`:
        - Allows configuration of GKE clusters, including names, regions and IP allocation policies 
        - Ensures that each cluster can by dynamically configured based on the input variables.
    - `outputs.tf`:
        - Exposes the key information like GKE Clusters such as cluster names and endpoints
        - Ensures that this information can be used by other resources in inter-module communication. 
### GAR Module:
- The GAR module provisions the GAR Registry in docker format.
- It consists of:
    - `gar.tf`: Terraform resourse code to create `Google Artifact Registry` clusters
    - `variables.tf`: 
        - Defines the input variables for the module for GAR
    - `outputs.tf`: 
        - It give the output of the GAR name

## DNS Module:
- This Module created a DNZ zone in the respective project. 
- It consists of: 
    - `main.tf`: 
        - Terraform resource to create a DNS Zone
    - `variables.tf`: 
        - Variables inludes like name of the `dns_zone` and `dns_name` 
    - `outputs.tf`: 
        - It returns the Nameserver records of the DNS. 
        - After we get these records, we need to create a service now request to delagate this dns in out `Optum` dns. 
        - Here is the [link](https://hive.hcp.uhg.com/post/14d997eb-4ce7-4c46-934e-30a1f1d36f0b) for the same , and this is the change ticket(CHG2339113) we used to make it done. 
### DB Module
- This module provisions one MySQL instance and one Redis
- It consists of:
    - `mysql.tf`: Terraform resourse code to create MySQL instance as per the configurations
    - `redis.tf`: Terraform resourse code to create Redis instance as per the configurations
    - `variables.tf`: 
        - Defines the input variables for the module for DB
            - Variables for MySQL
                - `mysql_instance_name`: Name of the MySQL database instance i.e. test-mysql-db
                - `mysql_tier`: Google database tier to be used for the instance i.e. db-n1-standard-1
                - `mysql_disk_type`: Disk type to be used for the storage of data for this instance i.e. PD_SSD
                - `mysql_disk_size`: Integer value of disk size in GB to be used for storing data of the MySQL instance. By default it will be dynamically expanding.
                - `mysql_database_version`: Version to be used for the instance i.e. MYSQL_8_0
                - `[REDACTED]`: Password to be used for the root account. It needs to be in the GH repository environment secrets and should be passed in through terraform command.
            - Variables for Redis
                - `redis_instance_name`: Name of the Redis database instance i.e. test-redis-db
                - `redis_version`: Version to be used for the instance i.e. REDIS_5_0
                - `redis_tier`: Google database tier to be used for the instance i.e. BASIC
                - `redis_memory_size`: Integer value of memory size to be used for the instance in GB i.e. 1
                - `redis_connect_mode`: Connection mode for the instance i.e. PRIVATE_SERVICE_ACCESS
    - `outputs.tf`: 
        - It gives the outputs of the MySQL and Redis instance names
### CloudArmor Module:
- This Module creates cloud armor policy .
- THis policy by default deny all requests and allow only `Optum-ips` and `nat-gateway-ip` which we are creating in the previous module. 
- Next, we need to assign this to the respective targets of loadbalancer .

### IAM Module:
- This Module , helps to assign our gcp groups created for developers to access lens and for devops group to access other owner resources.
- Make sure we have the group created before we ran this IAM module.

### GCS Module:
- This Module will be creating a Google Cloud Storage in us-central1 , this will be a Standard Storage Class