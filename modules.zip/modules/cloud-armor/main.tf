locals {
  allowed_ip_ranges = ["168.183.0.0/16", "149.111.0.0/16", "128.35.0.0/16", "161.249.0.0/16", "198.203.174.0/23", "198.203.176.0/22", "198.203.180.0/23"]
}

resource "google_compute_security_policy" "cloud_armor_policy" {
  #for_each = var.nat_ips
  name        = "bh-teraform-armor-policy"
  description = "Default security policy for Cloud Armor"
  project     = var.project_id
  
  # User labels for compliance
  #labels = var.labels
  
  rule {
    priority = 1000
    action   = "allow"
    description = "Allow requests from Optum IP address"
    match {
      versioned_expr = "SRC_IPS_V1"
      config {
        # allow these source ip ranges
        # src_ip_ranges = ["168.183.0.0/16", "149.111.0.0/16"]
        src_ip_ranges = local.allowed_ip_ranges
        }
    }
  }
  rule {
    priority = 2147483647
    action   = "deny(403)"
    match {
      versioned_expr = "SRC_IPS_V1"
      config {
        src_ip_ranges = ["*"]
      }
    }

  }
  # allow requests from the nat ip
    rule {
        priority = 1001
        action   = "allow"
        description = "Allow requests from the NAT IP"
        match {
            versioned_expr = "SRC_IPS_V1"
            config {
                src_ip_ranges = [ for key, ip in var.nat_ips : ip ]
            }
        }
    }
}
