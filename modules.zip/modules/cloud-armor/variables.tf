# variable "nat_ip" {
#   description = "The NAT IP address"
#   type        = string
  
# }

variable "nat_ips" {
  description = "The NAT IP addresses"
  type        = map(string)
}

variable "project_id" {
  description = "The project ID"
  type        = string
}

variable "labels" {
  description = "Labels to apply to Cloud Armor security policies"
  type        = map(string)
  default     = {}
}