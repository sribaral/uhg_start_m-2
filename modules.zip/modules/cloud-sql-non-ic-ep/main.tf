# # Reserve an IP address range for the Private Service Connection
# resource "google_compute_global_address" "private_service_access" {
#   name          = "private-service-access"
#   purpose       = "VPC_PEERING"
#   address_type  = "INTERNAL"
#   prefix_length = 16
#   network       = var.vpc_self_link
# }


#Create the private service connection
# resource "google_service_networking_connection" "private_service_connection" {
#   network = var.vpc_self_link
#   service = "servicenetworking.googleapis.com"
#   reserved_peering_ranges = [google_compute_global_address.private_service_access.self_link]

#   lifecycle {
#     ignore_changes = [reserved_peering_ranges]
#   }
# }

terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = ">= 5.34.0"
      #version = "5.28.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"    # ✅ Add beta provider
      version = ">= 5.34.0"
    }
  }
}

# Create a Cloud SQL Instance
resource "google_sql_database_instance" "tf_cloud_sql_instance" {
  provider = google-beta
  for_each = var.cloud_sql_db_instances_details
  name             = each.key
  database_version = var.database_version
  region           = each.value.primary_region
  deletion_protection = true

  settings {
    # https://docs.cloud.google.com/sql/docs/mysql/machine-series-overview#n2_machine_types
    tier = "db-perf-optimized-N-4"
    # the below is for enterprise only
    #tier               = "db-custom-${each.value.cpu_count}-${each.value.memory_size_mb}"
    disk_size          = each.value.disk_size
    disk_autoresize = false # By making this, we can have control over the disk size
    availability_type  = each.value.availability_type
    edition            = "ENTERPRISE_PLUS" #"ENTERPRISE"
    #activation_policy  = "ALWAYS"

    ip_configuration {
      ssl_mode       = "ENCRYPTED_ONLY"
      ipv4_enabled   = "false"
      private_network = var.vpc_self_link

    #   psc_config {
    #     psc_enabled = true
    #     allowed_consumer_projects = var.allowed_consumer_projects
    #   }
    }
    user_labels = var.labels

    backup_configuration {
      enabled            = true
      binary_log_enabled = each.value.availability_type == "REGIONAL" ? true : false
      transaction_log_retention_days = 7 # Required if binary_log_enabled is true
      backup_retention_settings {
        retained_backups = 14  # Must be > transaction_log_retention_days (7)
        retention_unit   = "COUNT"
      }
    }

    # database_flags {
    #   name  = "lower_case_table_names"
    #   value = "1"
    # }
    # database_flags {
    #   name  = "sql_mode"
    #   value = "NO_ENGINE_SUBSTITUTION"
    # }
    # database_flags {
    #   name  = "character_set_server"
    #   value = "latin1"
    # }
    # database_flags {
    #   name  = "explicit_defaults_for_timestamp"
    #   value = "off"
    # }
    deletion_protection_enabled = true
  }
  lifecycle {
    ignore_changes = [
      replication_cluster   # ✅ ignore the whole block for UI-managed DR
    ]
  }
}
resource "google_sql_database_instance" "tf_read_replica" {
  provider = google-beta
  for_each = { for instance, instance_details in var.cloud_sql_db_instances_details : instance => instance_details if instance_details.create_read_replica }
  name             = each.value.read_replica_name
  database_version = var.database_version
  master_instance_name = google_sql_database_instance.tf_cloud_sql_instance[each.key].name
  region           = each.value.read_replica_region
  deletion_protection = true

  settings {
    tier = "db-perf-optimized-N-4"
    #tier               = "db-custom-${each.value.cpu_count}-${each.value.memory_size_mb}"
    disk_size          = each.value.disk_size
    disk_autoresize = false # By making this, we can have control over the disk size
    availability_type  = each.value.availability_type
    edition            = "ENTERPRISE_PLUS" #"ENTERPRISE"
    #activation_policy  = "ALWAYS"
    user_labels = var.labels
    ip_configuration {
      ssl_mode       = "ENCRYPTED_ONLY"
      ipv4_enabled   = "false"
      private_network = var.vpc_self_link

    #   psc_config {
    #     psc_enabled = true
    #     allowed_consumer_projects = var.allowed_consumer_projects
    #   }
    }

    deletion_protection_enabled = true
  }
  
}