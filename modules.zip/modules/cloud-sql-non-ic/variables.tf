##******************************** Below for dynamic
variable "cloud_sql_db_instances_details" {
  description = "Map the cloud sql instance with their configurations"
  type = map(object({
    availability_type    = string # 'REGIONAL' or 'ZONAL'
    cpu_count            = number
    memory_size_mb       = number
    disk_size            = number
    edition              = string
    primary_region       = string
    create_read_replica  = bool   # true if read replica is needed
    read_replica_region  = string
    read_replica_name    = string
  }))
}

variable "database_version" {
    type = string
    description = "The database version for the Cloud SQL instance"
}

variable "project_id" {
  description = "The project ID to deploy the resources"
  type = string
}

variable "region" {
  description = "The project region to deploy the resources"
  type = string
}

variable "vpc_name" {
  description = "The name of the VPC"
  type = string
}

variable "disk_size" {
  default = 10
  description = "The size of the disk in GB"
}

variable "db_name" {
  default = "tf-db"
  description = "The name of the database to create"
}

variable "disk_type" {
  default = "PD_SSD"
  description = "The type of disk to use"
}

variable "availability_type" {
  default = "ZONAL" # 'REGIONAL' or 'ZONAL'
  description = "This specifies whether a MySql instance should be set up for high availability (REGIONAL) or single zone (ZONAL)"
}

variable "environment" {
  description = "The environment type, options are `enterprise` and `enterprise_plus`"
  default = "enterprise"
}

variable "cpu_count" {
  description = "The number of CPUs to use"
  default = 4
}

variable "memory_size_mb" {
  description = "The amount of memory to use"
  default = 16384
}

variable "ha_enabled" {
  description = "Whether to enable high availability for the Cloud SQL instance"
  type = bool
  default = false
}

variable "read_replica" {
  description = "Whether to enable read replica for the Cloud SQL instance"
  default = false
  type = bool
}

variable "vpc_self_link" {
  description = "The self-link of the VPC"
  type = string
}

variable "allowed_consumer_projects" {
  description = "List of allowed consumer projects for Private Service Connect (PSC)"
  type        = list(string)
}

variable "labels" {
  description = "Labels to apply to CloudSQL resources"
  type        = map(string)
  default     = {}
}