# Create a DNS zone in GCP
resource "google_dns_managed_zone" "dns_zone" {
    name = var.dns_zone_name # "example-zone"
    dns_name = var.dns_name # example.com.
    description = "Managed zone for the GCP project"
    labels = var.labels
}