# Output NS records
output "ns_records" {
  value = google_dns_managed_zone.dns_zone.name_servers
  description = "NS records for the managed zone"
}

# Output for the DNS name
output "dns_name" {
  value = google_dns_managed_zone.dns_zone.dns_name
  description = "value of the DNS name"
}

# Output for the DNS zone name
output "dns_zone_name" {
  value = google_dns_managed_zone.dns_zone.name
  description = "value of the DNS zone name"
}