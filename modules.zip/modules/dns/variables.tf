# Variable for the DNS zone name
variable "dns_zone_name" {
  type = string
  description = "value of the DNS zone name"
  default = "gcp-bh-dns-zone"
}


# DNS name for the managed zone
variable "dns_name" {
  type = string
  description = "The DNS name of the managed zone"
}

variable "labels" {
  description = "Labels to apply to DNS resources"
  type        = map(string)
  default     = {}
}

