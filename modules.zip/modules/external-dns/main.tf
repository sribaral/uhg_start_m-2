# # crate a service account for GKE Workload Identity
# resource "google_service_account" "external_dns" {
#   account_id   = "external-dns"
#   display_name = "External DNS Service Account"
#   project      = var.project_id
# }


# # Add DNS Admin role to the service account
# resource "google_project_iam_member" "external_dns_dns_admin" {
#   project = var.project_id
#   role    = "roles/dns.admin"
#   member  = "serviceAccount:${google_service_account.external_dns.email}"
# }

# # Create a namespace for ExternalDNS > this is already been creted in the GKE Cluster module

# # Associate GCP IAM service account with k8s Service account
# resource "google_project_iam_member" "external_dns_k8s" {
#   project = var.project_id
#   role    = "roles/iam.workloadIdentityUser"
#   member  = "serviceAccount:${var.project_id}.svc.id.goog[external-dns/external-dns-k8s-sa]"
# }   # This is the service account created in the GKE module

