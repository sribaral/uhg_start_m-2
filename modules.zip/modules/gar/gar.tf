# Create a Google Artifact Registry repository
resource "google_artifact_registry_repository" "docker_registry" {
  location = var.region
  repository_id = var.docker_registry_name
  description = "Docker registry for storing docker images"
    format = "DOCKER"
}