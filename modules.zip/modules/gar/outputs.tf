# Description: This file contains the output variables for the module
output "docker_registry_name" {
  value = google_artifact_registry_repository.docker_registry.repository_id
  description = "value of the docker registry name" 
}

