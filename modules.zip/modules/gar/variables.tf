# Define the input variables for the module
variable "region" {
  type = string
  description = "value of the region"
}


# Define the input variables for the module
variable "docker_registry_name" {
  type = string
  description = "value of the docker registry name" 
}