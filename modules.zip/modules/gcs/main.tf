# Create a Google Cloud Storage to Store datbase dumps.
variable "project_id" {
  description = "The project ID"
}
variable "region" {
  description = "The region to create the bucket in"
  default     = "us-central1"
}

variable "labels" {
  description = "Labels to apply to GCS buckets"
  type        = map(string)
  default     = {}
}

resource "google_storage_bucket" "db_dumps" {
  name          = "${var.project_id}-db-sql-dumps"
  location      = var.region
  project       = var.project_id
  force_destroy = true
  uniform_bucket_level_access = true
  labels        = var.labels
}

# Create a Google Cloud Storage to Store database import for any DR operations.
resource "google_storage_bucket" "db_imports" {
  name          = "${var.project_id}-dr-db-imports"
  location      = var.region
  project       = var.project_id
  force_destroy = true
  uniform_bucket_level_access = true
  labels        = var.labels
}