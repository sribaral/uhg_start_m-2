resource "google_container_cluster" "gke_cluster" {
  for_each = { for cluster in var.gke_cluster_info : cluster.cluster_name => cluster}
  name = each.value.cluster_name
    location = each.value.region
    deletion_protection = false

    network = var.network_id
    subnetwork = each.value.subnet_name
    enable_autopilot = true

    private_cluster_config {
        enable_private_nodes = true
        master_global_access_config {
            enabled = true
        }
    }


    # Add master authorized networks
    master_authorized_networks_config {
        dynamic "cidr_blocks" {
            for_each = var.master_authorized_networks_config
            content {
                cidr_block = cidr_blocks.value.cidr_block
                display_name = cidr_blocks.value.display_name
            }
        }
    }

}

# GKE Cluster Information
variable "gke_cluster_info" {
  description = "Information about the GKE clusters to create"
  type        = list(object({
    cluster_name = string
    region       = string
    subnet_name  = string
   # cluster_secondary_range_name = string
    # Add other fields as necessary
  }))
}


# ------------------------ Variables defined here ------------------

# Authorised networks for the GKE master
variable "master_authorized_networks_config" {
  description = "A list of authorized networks for the gke cluster master"
  type = list(object({
    cidr_block = string
    display_name = string
  }))
}


# Region where the GKE cluster will be created
variable "region" {
  type = string
  default = "us-central1"
}

# Network where the GKE cluster will be created
variable "network_id" {
  type = string
}

# VPC name output from the network module
variable "vpc_name" {
  type = string
}