# Authoized networks for the GKE master
locals {
  authorized_networks = [
      {
        cidr_block = "168.183.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "149.111.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "128.35.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "161.249.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "198.203.174.0/23"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "198.203.176.0/22"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "198.203.180.0/23"
        display_name = "Optum Ips"
      },
      # Newly added ones
      {
        cidr_block = "198.203.181.181/32"
        display_name = "Elk River"
      },
      {
        cidr_block = "198.203.175.175/32"
        display_name = "Chaska"
      },
      {
        cidr_block = "130.211.0.0/22"
        display_name = "Google Internal B"
      },
      {
        cidr_block = "198.203.177.177/32"
        display_name = "Plymouth"
      },
      {
        cidr_block = "35.191.0.0/16"
        display_name = "Google Internal A"
      }

  ]
}

locals {
  sa_roles =[
    "roles/container.nodeServiceAccount",
    "roles/container.admin",
    "roles/container.clusterAdmin",
    "roles/container.developer",
    "roles/container.viewer"
  ]
}

# Create a service account for GKE 
resource "google_service_account" "gke_service_account" {

  account_id = "gke-sa"
  display_name = "GKE Service Account created by Terraform"
  project = var.project_id
}  

# Assign roles to the service account
resource "google_project_iam_member" "gke_sa_roles" {
  for_each = toset(local.sa_roles)
  project = var.project_id  
  role = each.value
  member = "serviceAccount:${google_service_account.gke_service_account.email}"
}

# Create a GKE cluster
resource "google_container_cluster" "gke_cluster" {
  for_each = var.gke_cluster_configs

  name = each.value.cluster_name

  location = each.value.location
  project = var.project_id

  network = each.value.network
  subnetwork = each.value.subnetwork
  # Adding resource labels to the cluster
  resource_labels = merge(var.labels, lookup(each.value, "labels", {}))

  enable_autopilot = true 
    private_cluster_config {
        enable_private_nodes = true
        master_global_access_config {
            enabled = true
        }  
    }
    deletion_protection = true 

    # cluster_autoscaling {
    #   auto_provisioning_defaults {
    #     service_account = "gke-sa@emsqoqtg-sn72-sfl5-u0vu-nezked.iam.gserviceaccount.com"
    #     #service_account = google_service_account.gke_service_account.email
    #     oauth_scopes = ["https://www.googleapis.com/auth/cloud-platform"]
    #   }
    # }

    # Add master authorized networks
    master_authorized_networks_config {
      dynamic "cidr_blocks" {
        for_each = local.authorized_networks
        content {
            cidr_block = cidr_blocks.value.cidr_block
            display_name = cidr_blocks.value.display_name
        }
      }
  }

    # maintenance_policy 
  maintenance_policy {
    recurring_window {
      start_time = "2025-05-20T05:00:00Z" # 05:00 AM UTC , 10:30 AM IST , 12:00 PM CT
      end_time = "2025-05-20T11:00:00Z" # 11:00 AM UTC , 4:30 PM IST , 6:00 PM CT
      recurrence = "FREQ=WEEKLY;BYDAY=SA,SU"
  }
}

  depends_on = [ google_service_account.gke_service_account ]

}