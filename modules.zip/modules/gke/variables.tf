# ------------------------ Variables defined here ------------------

variable "project_id" {
  description = "Project ID"
    type = string   
}


# GKE Cluster Information
variable "gke_cluster_configs" {
  description = "Configuration of the gke clusters"
    type = map(object({
        cluster_name = string
        location = string
        network = string
        subnetwork = string
        }))
}



variable "labels" {
  description = "Base labels applied to GKE resources"
  type        = map(string)
  default     = {}
}

