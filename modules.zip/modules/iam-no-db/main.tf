variable "project_id" {
  description = "The project ID"
}


locals {
    transformed_project_id = replace(var.project_id, "-", "_")
    lens_developer_roles = [
        "roles/container.developer",
        "roles/container.clusterViewer",
        "roles/logging.viewer"
    ]
    devops_roles = [
        "roles/editor"
    ]    
}


# Assign permissions to the Developer Group for accessing LENS
resource "google_project_iam_member" "tf-lens-developer-iam" {
  for_each = toset(local.lens_developer_roles)
  project  = var.project_id
  role     = each.key
  #member = "group:GCP_emsqoqtg_sn72_sfl5_u0vu_nezked_devops@groups.optum.com"
  member = "group:GCP_${local.transformed_project_id}_lens@groups.optum.com"
}


# Assign permissions to the DevOps Group
resource "google_project_iam_member" "tf-devops-iam" {
  for_each = toset(local.devops_roles)
  project  = var.project_id
  role     = each.key
  member = "group:GCP_${local.transformed_project_id}_devops@groups.optum.com"
}


