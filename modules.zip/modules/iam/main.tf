variable "project_id" {
  description = "The project ID"
}


locals {
    transformed_project_id = replace(var.project_id, "-", "_")
    lens_developer_roles = [
        "roles/container.developer",
        "roles/container.clusterViewer",
        "roles/logging.viewer"
    ]
    devops_roles = [
        "roles/editor"
        // Security Admin
    ]
    db_admin_roles =[
      "roles/cloudsql.admin",
      "roles/logging.viewer"
    ]
    db_developer_permissions = [
      "cloudsql.databases.get",
      "cloudsql.databases.list",
      "cloudsql.instances.executeSql",
      "cloudsql.instances.get",
      "cloudsql.instances.list",
      "cloudsql.instances.login",
      "cloudsql.users.get",
      "cloudsql.users.list"
    ]
}

# Assign permissions to the Developer Group for accessing LENS
resource "google_project_iam_member" "tf-lens-developer-iam" {
  for_each = toset(local.lens_developer_roles)
  project  = var.project_id
  role     = each.key
  #member = "group:GCP_emsqoqtg_sn72_sfl5_u0vu_nezked_devops@groups.optum.com"
  member = "group:GCP_${local.transformed_project_id}_lens@groups.optum.com"
}


# Create a database developer IAM role
resource "google_project_iam_custom_role" "tf-db-developer-role" {
  role_id     = "tf_db_developer_role"
  title       = "Database Developer Role"
  description = "Custom role for database developers with limited permissions"
  project     = var.project_id
  permissions = local.db_developer_permissions
}

# Assign permissions to the DevOps Group
resource "google_project_iam_member" "tf-devops-iam" {
  for_each = toset(local.devops_roles)
  project  = var.project_id
  role     = each.key
  member = "group:GCP_${local.transformed_project_id}_devops@groups.optum.com"
}

# Assign permissions to the DB Admin Group
resource "google_project_iam_member" "tf-db-admin-iam" {
  for_each = toset(local.db_admin_roles)
  project  = var.project_id
  role     = each.key
  member = "group:GCP_${local.transformed_project_id}_db_admins@groups.optum.com"
} 

# Assign permissions to the Database Developer Group
resource "google_project_iam_member" "tf-db-developer-iam" {
  project  = var.project_id
  role     = google_project_iam_custom_role.tf-db-developer-role.name
  member = "group:GCP_${local.transformed_project_id}_appdb_users@groups.optum.com"
}
