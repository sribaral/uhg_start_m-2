# resource "google_redis_instance" "tf_test_valkey" {
#   name = "test-valkey"
#     memory_size_gb = 1
#     region = "us-central1"
#     tier = "BASIC"
#     authorized_network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
#     connect_mode = "PRIVATE_SERVICE_ACCESS"
# }


