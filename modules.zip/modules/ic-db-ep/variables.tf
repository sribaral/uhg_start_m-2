##******************************** Below for dynamic
variable "cloud_sql_instances_details" {
  description = "Map the cloud sql instance with their configurations"
  type = map(object
  (
    {
    availability_type = string # 'REGIONAL' or 'ZONAL'
    cpu_count = number
    memory_size_mb = number
    disk_size = number
    edition = string
    primary_region = string
    create_read_replica = bool # true if read replica is needed
    read_replica_region = string
    read_replica_name = string
  }
  )
  )
}

# MySQL Database Version
variable "database_version" {
  description = "The database version"
  type        = string
  default = "MYSQL_8_0"
}


variable "project_id" {
  type = string
  description = "value of the project id"
}

variable "labels" {
  description = "Labels to apply to CloudSQL resources"
  type        = map(string)
  default     = {}
}
