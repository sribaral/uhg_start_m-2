# Create a CloudSql Instance 

terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      version = ">= 5.34.0"
      #version = "5.28.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"    # ✅ Add beta provider
      version = ">= 5.34.0"
    }
  }
}

resource "google_sql_database_instance" "tf_cloud_sql_instance" {
  provider = google-beta # ✅ Use the beta provider for Cloud SQL instance creation
  for_each = var.cloud_sql_instances_details
  name             = each.key #var.instance_name
  database_version = var.database_version
  region = each.value.primary_region #var.region
  deletion_protection = true
  settings {
    # https://docs.cloud.google.com/sql/docs/mysql/machine-series-overview#n2_machine_types
    # ENTERPRISE_PLUS uses db-perf-optimized-N-*, ENTERPRISE uses db-custom-*
    tier = each.value.edition == "ENTERPRISE_PLUS" ? "db-perf-optimized-N-4" : "db-custom-${each.value.cpu_count}-${each.value.memory_size_mb}"
    disk_size = each.value.disk_size
    disk_autoresize = false # By making this, we can have control over the disk size
    availability_type = each.value.availability_type
    edition = each.value.edition # Dynamic: ENTERPRISE or ENTERPRISE_PLUS
    user_labels = var.labels

    ip_configuration {
      ssl_mode = "ENCRYPTED_ONLY"
      ipv4_enabled = "false"
      psc_config {
        psc_enabled = true
        allowed_consumer_projects = [ "${var.project_id}", "seyxwevo-gu1w-n2uv-41mp-8wmbkd" ]
      }
    }
    backup_configuration {
        enabled = true
        # For MySQL instances, ensure that settings.backup_configuration.binary_log_enabled is set to true for HA. 
        binary_log_enabled = each.value.availability_type == "REGIONAL" ? true : false
        transaction_log_retention_days = 7 # Required if binary_log_enabled is true
        backup_retention_settings {
          retained_backups = 14  # Must be > transaction_log_retention_days (7)
          retention_unit   = "COUNT"
        }
    }
    database_flags {
      name  = "lower_case_table_names"
      value = "1"
    }
    database_flags {
      name  = "sql_mode"
      value = "NO_ENGINE_SUBSTITUTION"
    }
    database_flags {
      name  = "character_set_server"
      value = "latin1"
    }
    database_flags {
      name  = "explicit_defaults_for_timestamp"
      value = "off"
    }
    deletion_protection_enabled = true
    
  }
  lifecycle {
    ignore_changes = [ 
      replication_cluster   # ✅ ignore the whole block for UI-managed DR
     ]
  }

}

# Conditional creation of read replica
resource "google_sql_database_instance" "tf_read_replica" {
  provider = google-beta # ✅ Use the beta provider for Cloud SQL instance creation
  for_each = { for instance, instance_details in var.cloud_sql_instances_details : instance => instance_details if instance_details.create_read_replica }
  name = each.value.read_replica_name
  region = each.value.read_replica_region
  database_version = var.database_version
  master_instance_name = google_sql_database_instance.tf_cloud_sql_instance[each.key].name
  deletion_protection = true
  settings {
    # ENTERPRISE_PLUS uses db-perf-optimized-N-*, ENTERPRISE uses db-custom-*
    tier = each.value.edition == "ENTERPRISE_PLUS" ? "db-perf-optimized-N-4" : "db-custom-${each.value.cpu_count}-${each.value.memory_size_mb}"
    edition = each.value.edition # Must match primary instance edition
    disk_autoresize = false
    user_labels = var.labels
    ip_configuration {
      ssl_mode = "ENCRYPTED_ONLY"
      ipv4_enabled = "false"
      psc_config {
        psc_enabled = true
        allowed_consumer_projects = [ "${var.project_id}", "seyxwevo-gu1w-n2uv-41mp-8wmbkd" ]
      } 
    }
    database_flags {
      name  = "lower_case_table_names"
      value = "1"
    }
    database_flags {
      name  = "sql_mode"
      value = "NO_ENGINE_SUBSTITUTION"
    }
    database_flags {
      name  = "character_set_server"
      value = "latin1"
    }
    database_flags {
      name  = "explicit_defaults_for_timestamp"
      value = "off"
    }
    deletion_protection_enabled = true
  }
  timeouts {
    create = "30m"
  }
  lifecycle {
    ignore_changes = [ database_version ]
  }
}


# variable "project_id" {
#   type = string
#   description = "value of the project id"
# }

# variable "instance_name" {
#   description = "The name of the Cloud SQL instance"
#   type        = string
# }

# variable "database_version" {
#   description = "The database version"
#   type        = string
#   default = "MYSQL_8_0"
# }

# variable "region" {
#   description = "The region where the Cloud SQL instance will be created"
#   type        = string
#   #default = "us-central1"
# }

# variable "cpu_count" {
#     description = "The number of CPUs to use"
#     #default = 4
#     type = number
# }

# variable "memory_size_mb" {
#     description = "The amount of memory to use"
#     #default = 16384
#     type = number
# }


# variable "disk_size" {
#     #default = 128
#     description = "The size of the disk in GB"
#     type = number
# }

# variable "availability_type" {
#     default = "ZONAL" # 'REGIONAL' or 'ZONAL'
#     description = "This specifies whether a MySql instance should be set up for  high availability (REGIONAL) or single zone (ZONAL)"
# }

# # Output the instance connection name
# output "instance_connection_name" {
#   value = google_sql_database_instance.tf_cloud_sql_instance.connection_name
# }

# # Output the instance name
# output "instance_name" {
#   value = google_sql_database_instance.tf_cloud_sql_instance.name
# }

# # Output the instance IP address
# output "instance_ip_address" {
#   value = google_sql_database_instance.tf_cloud_sql_instance.ip_address
# }



##******************************** Below for dynamic
# variable "cloud_sql_instances_details" {
#   description = "Map the cloud sql instance with their configurations"
#   type = map(object
#   (
#     {
#     availability_type = string # 'REGIONAL' or 'ZONAL'
#     cpu_count = number
#     memory_size_mb = number
#     disk_size = number
#     edition = string
#     region = string
#   }
#   )
#   )
# }

# variable "edition" {
#   description = "The edition of the Cloud SQL instance"
#   type        = string
# }