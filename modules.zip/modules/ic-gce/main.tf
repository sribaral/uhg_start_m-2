# Create a gce instance in host project in us-central1 region

resource "google_compute_instance" "tf_gce_instances" {
  name         = "ic-gce-instance"
    machine_type = "n1-standard-1"
    zone         = "us-central1-a"
    boot_disk {
        initialize_params {
        image = "projects/debian-cloud/global/images/debian-12-bookworm-v20250513"
        size  = 10
        type  = "pd-balanced"
        }
    }
    network_interface {
        network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
        subnetwork = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/regions/us-central1/subnetworks/bh-sc-nonprod-subnet"
    }
    tags = ["vm", "us-central1"]

    # service_account {
    #     scopes = ["cloud-platform"]
    #     email = "bh-terraform-ic@tzmwemry-89yl-akiu-4css-6afkjm.iam.gserviceaccount.com"
    # }
}

#gcloud compute instances create bh-gce-instance --zone=us-central1-a --machine-type=n1-standard-1 --network=prod-pcn-shared-vpc --subnet=bh-sc-nonprod-subnet --image=debian-11
