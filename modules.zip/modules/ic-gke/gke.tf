# Authoized networks for the GKE master
locals {
  authorized_networks = [
      {
        cidr_block = "168.183.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "149.111.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "128.35.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "161.249.0.0/16"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "198.203.174.0/23"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "198.203.176.0/22"
        display_name = "Optum Ips"
      },
      {
        cidr_block = "198.203.180.0/23"
        display_name = "Optum Ips"
      },
      # Newly added ones
      {
        cidr_block = "198.203.181.181/32"
        display_name = "Elk River"
      },
      {
        cidr_block = "198.203.175.175/32"
        display_name = "Chaska"
      },
      {
        cidr_block = "130.211.0.0/22"
        display_name = "Google Internal B"
      },
      {
        cidr_block = "198.203.177.177/32"
        display_name = "Plymouth"
      },
      {
        cidr_block = "35.191.0.0/16"
        display_name = "Google Internal A"
      }

  ]
}

resource "google_container_cluster" "gke_cluster" {
  for_each = { for cluster in var.gke_cluster_info : cluster.cluster_name => cluster}
  #for_each = toset(var.cluster_subnets)
  name = each.value.cluster_name
  location = each.value.region
  deletion_protection = true

  network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
  subnetwork = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/regions/${each.value.region}/subnetworks/${each.value.subnet_name}" # this should be the name , we gave during the issue template 
  enable_autopilot = true
  
  # Adding resource labels to the cluster
  resource_labels = var.labels

  ip_allocation_policy {
    cluster_secondary_range_name = "${each.value.cluster_secondary_range_name}"
  }
  

  private_cluster_config {
    enable_private_endpoint   = false
    enable_private_nodes      = true
  }

  node_pool_auto_config {
    network_tags {
      tags = ["${each.value.region}"]
    }
  }

  release_channel {
    channel = "REGULAR"
  }

  # Add master authorized networks
  master_authorized_networks_config {
    dynamic "cidr_blocks" {
        for_each = local.authorized_networks
        content {
            cidr_block = cidr_blocks.value.cidr_block
            display_name = cidr_blocks.value.display_name
        }
    }
  }

  provisioner "local-exec" {
    command = "sleep 180"
  }

  # maintenance_policy 
  maintenance_policy {
    recurring_window {
      # # Sunday , Monday 10 AM IST 
      # start_time = "2025-04-13T04:30:00Z" # Sunday 10 AM IST converted to 4:30 AM UTC
      # end_time = "2025-04-13T09:30:00Z" # Sunday 11 AM IST converted to 9:30 AM UTC
      # recurrence = "FREQ=WEEKLY;BYDAY=SU"
      start_time = "2025-05-20T05:00:00Z" # 05:00 AM UTC , 10:30 AM IST , 12:00 PM CT
      end_time = "2025-05-20T11:00:00Z" # 11:00 AM UTC , 4:30 PM IST , 6:00 PM CT
      recurrence = "FREQ=WEEKLY;BYDAY=SA,SU"
  }
}
}


# 100.71.0.0/16 > Secondary
# 10.20.56.0/22 > Primary


# gcloud command to disbale deletion protection for gke cluster
# gcloud container clusters update ic-bh-sc-nonprod-pri --region=us-central1 --update-deletion-protection=false
# gcloud container clusters update ic-bh-sc-nonprod-sec --region=us-east4 --update-deletion-protection=false