# Region Variables
variable "region" {
  description = "The GCP region to deploy resources"
  type        = string
  default     = "us-central1"
}

# GKE Cluster Information
variable "gke_cluster_info" {
  description = "Information about the GKE clusters to create"
  type        = list(object({
    cluster_name = string
    region       = string
    subnet_name  = string
    cluster_secondary_range_name = string
    # Add other fields as necessary
  }))
}

variable "labels" {
  description = "Base labels applied to GKE resources"
  type        = map(string)
  default     = {}
}


# Master Authorized Networks Configuration
# variable "master_authorized_networks_config" {
#   description = "Master authorized networks configuration"
#   type        = list(object({
#     cidr_block   = string
#     display_name = string
#   }))
# }