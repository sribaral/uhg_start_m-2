resource "google_redis_instance" "tf_redis_instance" {
  name           = var.redis_instance_name
  #region         = "us-central1"
  project        = var.project_id
  tier           = var.redis_tier #"BASIC"
  memory_size_gb = var.redis_memory_size_gb # 1

  location_id = var.redis_zone
  authorized_network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
  connect_mode       = "PRIVATE_SERVICE_ACCESS"

  auth_enabled = true

  labels = var.labels
} 

