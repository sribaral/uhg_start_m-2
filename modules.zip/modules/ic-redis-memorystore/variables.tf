variable "project_id" {
  type = string
}

variable "redis_instance_name" {
  type = string
}

variable "redis_tier" {
  type = string
}


variable "redis_memory_size_gb" {
  type = number
}

variable "redis_zone" {
  type = string
}

variable "labels" {
  description = "Labels to apply to Redis resources"
  type        = map(string)
  default     = {}
}