resource "google_container_cluster" "gke_cluster" {
  for_each = { for cluster in var.gke_cluster_info : cluster.cluster_name => cluster}
  #for_each = toset(var.cluster_subnets)
  name = each.value.cluster_name
  location = var.region

  network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
  subnetwork = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/regions/us-central1/subnetworks/bh-sc-nonprod-subnet" # this should be the name , we gave during the issue template 
  enable_autopilot = true
  deletion_protection = false
  ip_allocation_policy {
    cluster_secondary_range_name = "bh-sc-nonprod-secondary-subnet"
  }
  

  private_cluster_config {
    enable_private_endpoint   = false
    enable_private_nodes      = true
  }

  node_pool_auto_config {
    network_tags {
      tags = ["us-central1"]
    }
  }

  release_channel {
    channel = "REGULAR"
  }

  # Add master authorized networks
  master_authorized_networks_config {
    dynamic "cidr_blocks" {
        for_each = var.master_authorized_networks_config
        content {
            cidr_block = cidr_blocks.value.cidr_block
            display_name = cidr_blocks.value.display_name
        }
    }
  }

  provisioner "local-exec" {
    command = "sleep 180"
  }
}


# 100.71.0.0/16 > Secondary
# 10.20.56.0/22 > Primary
