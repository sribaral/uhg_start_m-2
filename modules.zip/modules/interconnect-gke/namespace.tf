
resource "kubernetes_namespace" "primary_namespaces" {
  for_each = var.gke_cluster_info[0].namespaces

  metadata {
    name = each.key

    annotations = {
      name = "${each.key}-namespace"
    }

    labels = {
      namespace = each.key
    }
  }

  provider = kubernetes.primary
  depends_on = [ google_container_cluster.gke_cluster ]
}

resource "kubernetes_namespace" "secondary_namespaces" {
  for_each = var.gke_cluster_info[1].namespaces

  metadata {
    name = each.key

    annotations = {
      name = "${each.key}-namespace"
    }

    labels = {
      namespace = each.key
    }
  }

  provider = kubernetes.secondary
  depends_on = [ google_container_cluster.gke_cluster ]
}

# # create a wait time for the namespaces to be created after the cluster is created
# resource "null_resource" "wait_for_namespaces" {
#   provisioner "local-exec" {
#     command = "sleep 60"
#   }

#   depends_on = [google_container_cluster.gke_cluster]
# }

# create a default deny network policy for the Primary namespaces
resource "kubernetes_network_policy" "default_deny_network_policy_pri" {

  for_each = var.gke_cluster_info[0].namespaces

  metadata {
    name = "default-deny-network-policy"
    namespace = each.key
  }

  spec {

    pod_selector {
      match_labels = {}
    }
    policy_types = ["Ingress", "Egress"]

    egress {
      ports {
        protocol = "UDP"
        port     = 53
      }
      ports {
        protocol = "TCP"
        port     = 53
      }
    }
  }

  provider = kubernetes.primary
  depends_on = [kubernetes_namespace.primary_namespaces]
}

# create a default deny network policy for the Secondary namespaces
resource "kubernetes_network_policy" "default_deny_network_policy_sec" {

  for_each = var.gke_cluster_info[1].namespaces

  metadata {
    name = "default-deny-network-policy"
    namespace = each.key
  }

  spec {

    pod_selector {
      match_labels = {}
    }
    policy_types = ["Ingress", "Egress"]

    egress {
      ports {
        protocol = "UDP"
        port     = 53
      }
      ports {
        protocol = "TCP"
        port     = 53
      }
    }
  }

  provider = kubernetes.secondary
  depends_on = [kubernetes_namespace.secondary_namespaces]
}

# 

