# This file contains the output variables for the GKE  module

# Output the GKE cluster names
output "gke_cluster_names" {
  value = [for cluster in google_container_cluster.gke_cluster : cluster.name]
  description = "value of the GKE cluster names"
}

# Output the GKE cluster endpoints
output "gke_cluster_endpoints" {
  value = {for key, cluster in google_container_cluster.gke_cluster : key => cluster.endpoint}
  description = "value of the GKE cluster endpoints"
}