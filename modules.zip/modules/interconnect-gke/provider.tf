data "google_client_config" "client-config" {
  depends_on = [google_container_cluster.gke_cluster]
}


# create a null resource to sleep 180 
# resource "null_resource" "delay-config" {
#   provisioner "local-exec" {
#     command = "sleep 180"
#     #when = destroy
#   }
# }



provider "kubernetes" {
  alias = "primary"
  host = google_container_cluster.gke_cluster[var.gke_cluster_info[0].cluster_name].endpoint # "34.71.136.69"
  token = data.google_client_config.client-config.access_token
  cluster_ca_certificate = base64decode(google_container_cluster.gke_cluster[var.gke_cluster_info[0].cluster_name].master_auth.0.cluster_ca_certificate)
}

provider "kubernetes" {
  alias = "secondary"
  host = google_container_cluster.gke_cluster[var.gke_cluster_info[1].cluster_name].endpoint
  token = data.google_client_config.client-config.access_token
  cluster_ca_certificate = base64decode(google_container_cluster.gke_cluster[var.gke_cluster_info[1].cluster_name].master_auth.0.cluster_ca_certificate)
}

# # # delay the subnet destroy
# resource "null_resource" "delay" {
#   provisioner "local-exec" {
#     when = destroy
#     command = "sleep 600"
#   }
#   depends_on = [google_compute_subnetwork.tf_subnets]
# }

# # delay the cluster destroy 
# resource "null_resource" "delay" {
#   provisioner "local-exec" {
#     when = destroy
#     command = "sleep 180"
#   }
#   depends_on = [google_container_cluster.gke_cluster]
# }


# # create a null resource to sleep 180 
# resource "null_resource" "delay" {
#   provisioner "local-exec" {
#     command = "sleep 180"
#   }
# }