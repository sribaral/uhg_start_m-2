# variable "master_authorized_networks_config" {
#   description = "The list of authorized networks for the GKE master"
#   type = list(object({
#     cidr_block = list(object({
#       cidr_block = string
#     }))
#     display_name = string
#   }))
  
# }

# Authorised networks for the GKE master
variable "master_authorized_networks_config" {
  description = "A list of authorized networks for the gke cluster master"
  type = list(object({
    cidr_block = string
    display_name = string
  }))
}

# Cluster subnets for the GKE cluster 
# This is a map of the cluster names to the subnets
variable "gke_cluster_info" {
  type = list(object({
    cluster_name = string
    #subnet_name = string
    namespaces = set(string)
  }))
  description = "value of the cluster subnets and namespaces" 
}

# Region where the GKE cluster will be created
variable "region" {
  type = string
  default = "us-central1"
}

# Network where the GKE cluster will be created
variable "network_id" {
  type = string
}

# VPC name output from the network module
variable "vpc_name" {
  type = string
}