# Terraform Configuration for Google Cloud VPC and Subnet
- This Module contains terraform configuration to create a VPC and subnet in Google Cloud Platform 
## Files and Structure
- `network.tf`:
    - This consists of the resource to create VPC and Subnet
    - This manifest can create a VPC and mulitple subnets in the same vpc. For that we have used `count`
- `variables.tf`:  
    - This consists of the variables that are defined in teh networks.tf manifest file. 
- `outputs.tf`  
    - VPC name and Subnets can be taken as a outpusts from here 
- `firewalls.tf`  
    - This file contains code to create necessary firewall rules. Rules created are detailed below:
        - Ingress
            - Allow internal ingress traffic on tcp ports 22, 80, 8080, 443, 3306 and 6379 for source and destination range of the local subnet
            - Allow external ingress traffic on tcp ports 22, 80, 8080, 443, 3306 and 6379 for sources of tower_ips as per [Optum IPs](https://dojo360.optum.com/docs/cloud/azure/networking/references/profiles/optum-ips/index.html)
        - Egress
            - Allow external engress traffic on tcp ports 80, 8080, 443 for destination range as per [Optum IPs](https://dojo360.optum.com/docs/cloud/azure/networking/references/profiles/optum-ips/index.html)
            - Allow external engress traffic for email relay for required destination range as per [Optum IPs](https://dojo360.optum.com/docs/cloud/azure/networking/references/profiles/optum-ips/index.html)
            - Deny external egress traffic for everything else


