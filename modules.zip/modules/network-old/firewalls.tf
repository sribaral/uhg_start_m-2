# create a rule for GCP firewall to allow internal ingress traffic on tcp ports 22, 80, 8080, 443, 3306 and 6379 for source and destination range of the local subnet
resource "google_compute_firewall" "allow_internal_ingress" {
  name    = "allow-internal-ingress"
  network = google_compute_network.tf_vpc_network.self_link
  direction = "INGRESS"

  allow {
    protocol = "tcp"
    ports    = ["22", "80", "8080", "443", "3306", "6379"]
  }

  source_ranges = [
    #google_compute_subnetwork.tf_subnet.ip_cidr_range,
    for subnet in google_compute_subnetwork.tf_subnets : subnet.ip_cidr_range
  ]

  destination_ranges = [
    for subnet in google_compute_subnetwork.tf_subnets : subnet.ip_cidr_range
  ]

  priority = 1000
}

# Allow firewall for GCP  IAP to login to the VMs
resource "google_compute_firewall" "allow_iap_ingress" {
  name    = "allow-iap-ingress"
  network = google_compute_network.tf_vpc_network.self_link
  direction = "INGRESS"

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }

  source_ranges = [
    "35.235.240.0/20"
    ]
}

# create a rule for GCP firewall to allow external ingress traffic on tcp ports 22, 80, 8080, 443, 3306 and 6379 for source range: var.optum_ips.tower_ips
# resource "google_compute_firewall" "allow_external_ingress" {
#   name    = "allow-external-ingress"
#   network = google_compute_network.tf_vpc_network.self_link
#   direction = "INGRESS"

#   allow {
#     protocol = "tcp"
#     ports    = ["22", "80", "8080", "443", "3306", "6379"]
#   }

#   source_ranges = var.optum_ips.tower_ips

#   destination_ranges = [
#     google_compute_subnetwork.tf_subnet.ip_cidr_range,
#   ]

#   priority = 1000
# }

# TODO: Allow external ingress: tcp, ports 80, 443 for Whitehat

# # create a rule for GCP firewall to allow external engress traffic on tcp ports 80, 8080, 443 for destination range: var.optum_ips.tower_ips
# resource "google_compute_firewall" "allow_internal_egress" {
#   name    = "allow-external-egress"
#   network = google_compute_network.tf_vpc_network.self_link
#   direction = "EGRESS"

#   allow {
#     protocol = "tcp"
#     ports    = ["80", "8080", "443"]
#   }

#   source_ranges = [
#     google_compute_subnetwork.tf_subnet.ip_cidr_range,
#   ]

#   destination_ranges = var.optum_ips.tower_ips

#   priority = 1000
# }

# TODO: create a rule for Logging: Dynatrace and Splunk
# TODO: create a rule for ECG: Gateway and Quick Connect

# create a rule for GCP firewall to allow external engress traffic for email relay for required destination range
# resource "google_compute_firewall" "allow_email_relay_egress" {
#   name    = "allow-email-relay-egress"
#   network = google_compute_network.tf_vpc_network.self_link
#   direction = "EGRESS"

#   allow {
#     protocol = "tcp"
#     ports    = ["25"]
#   }

#   source_ranges = [
#     google_compute_subnetwork.tf_subnet.ip_cidr_range,
#   ]

#   destination_ranges = ["52.149.252.24"]
# }

# TODO: create a rule for license servers
# TODO: create a rule for other API services i.e. additional google services, Stargate and other API services

# create a rule for GCP firewall to deny external egress traffic for everything else than above rules with lower priority
/*
resource "google_compute_firewall" "deny_external_egress" {
  name    = "deny-external-egress"
  network = google_compute_network.tf_vpc_network.self_link
  direction = "EGRESS"

  allow {
    protocol = "all"
  }

  source_ranges = [
    google_compute_subnetwork.tf_subnet.ip_cidr_range,
  ]

  destination_ranges = ["0.0.0.0/0"]  # All IP addresses
}
*/

