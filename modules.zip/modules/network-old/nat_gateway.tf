# Create a Static IP for Nat Gateway 
resource "google_compute_address" "nat_ip" {
  name = var.nat_ip_name
  region = var.region
}

# Create a Cloud Router 
# This will be used to route traffic to the NAT Gateway
# 
resource "google_compute_router_nat" "nat_gateway" {
  name = var.nat_name
  router = google_compute_router.cloud_router.name
  region = google_compute_router.cloud_router.region
  nat_ip_allocate_option = "MANUAL_ONLY"
  source_subnetwork_ip_ranges_to_nat = "LIST_OF_SUBNETWORKS"
  nat_ips = [google_compute_address.nat_ip.id]
  dynamic "subnetwork" {
    for_each = { for k,v in var.subnets : k => v if v.private }
    content {
      name = google_compute_subnetwork.tf_subnets[subnetwork.key].self_link
      source_ip_ranges_to_nat = ["ALL_IP_RANGES"]
    }
  }
}