# VPC Creation
# Create a VPC with the name specified in the variables.tf file
resource "google_compute_network" "tf_vpc_network" {
  name = var.vpc_name
  auto_create_subnetworks = false
  project = var.project_id
  # delete_default_routes_on_create = true # default routes (0.0.0.0/0) will be deleted immediately after network creation
}




# Subnet Creation
resource "google_compute_subnetwork" "tf_subnets" {
  for_each = var.subnets
  name = each.key
  ip_cidr_range = each.value.ip_cidr_range
  network = google_compute_network.tf_vpc_network.id
  region = each.value.subnet_region
  private_ip_google_access = each.value.private
}



# delay the subnet destroy
resource "null_resource" "delay" {
  provisioner "local-exec" {
    when = destroy
    command = "sleep 600"
  }
  depends_on = [google_compute_subnetwork.tf_subnets]
}
