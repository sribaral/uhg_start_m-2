# This file contains the output variables for the network module


# Output the VPC ID
output "vpc_id" {
 value = google_compute_network.tf_vpc_network.id 
}

# Output the VPC self link
output "vpc_self_link" {
 value = google_compute_network.tf_vpc_network.self_link
}

# Output the subnet names
output "subnet_names" {
  value = [for subnet in google_compute_subnetwork.tf_subnets : subnet.name]
  description = "value of the subnet names"
}

# Output the nat ip
output "nat_ip" {
  value = google_compute_address.nat_ip.address
  description = "value of the nat ip"
}

# output the vpc name
output "vpc_name" {
  value = var.vpc_name
  description = "value of the VPC name"
}