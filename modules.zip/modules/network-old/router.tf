resource "google_compute_router" "cloud_router" {
  name = var.router_name
  network = google_compute_network.tf_vpc_network.id
  region = var.region
}
