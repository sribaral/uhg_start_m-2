variable "project_id" {
  description = "The project ID to deploy the resources"
  type = string
}

variable "region" {
  description = "The region to deploy the resources"
  type = string
}

variable "vpc_name" {
  description = "The name of the VPC"
  type = string
}

variable "subnets" {
  description = "The list of subnets to create"
  type = map(object({
    ip_cidr_range = string
    private = bool
  }))
}

# variable "cluster_subnets" {
#   description = "The list of subnets to create"
#   type = map(object({
#     ip_cidr_range = string
#     private = bool
#   }))
# }

# Router Variable
variable "router_name" {
  description = "The name of the Cloud router"
  type = string
}


# NAT Gateway Variable
variable "nat_name" {
  description = "The name of the NAT Gateway"
  type = string
}


# NAT IP Variable 
variable "nat_ip_name" {
  description = "The name of the NAT IP"
  type = string
}