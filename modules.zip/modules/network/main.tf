
# Create a VPC
resource "google_compute_network" "terraform-vpc" {
  name = var.vpc_name
  auto_create_subnetworks = false
  project = var.project_id
}

# Create a Subnetworks in different regions
resource "google_compute_subnetwork" "tf-subnet" {
    for_each = var.subnet_configs
    name = "${var.vpc_name}-${each.key}-subnet" # bh-vpc-us-central1-subnet
    ip_cidr_range = each.value.cidr_range
    region = each.key
    network = google_compute_network.terraform-vpc.self_link
}


# Create a Static Ip for the NAT Gateway
resource "google_compute_address" "tf-nat-ip" {
    for_each = toset(var.regions)
    name = var.nat_ip_name[each.key]
    region = each.key
    project = var.project_id
    labels = var.labels
}

# Create a Router
resource "google_compute_router" "tf-router" {
  for_each = toset(var.regions)
  name = var.router_name[each.key]
  network = google_compute_network.terraform-vpc.self_link
  region = each.key
}

# Create a NAT Gateway
resource "google_compute_router_nat" "tf-nat_gateway" {
  for_each = toset(var.regions)

  name = "${var.nat_ip_name[each.key]}-nat-gateway"
  router = google_compute_router.tf-router[each.key].name
  region = each.key
  nat_ip_allocate_option = "MANUAL_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
  project = var.project_id

  depends_on = [ google_compute_router.tf-router ]
  nat_ips = [google_compute_address.tf-nat-ip[each.key].self_link]
}




# regions = ["us-central1","us-east4"]

# subnet_configs = {
#     "us-central1" = {
#         cidr_range = "10.0.0.0/16"
#     },
#     "us-east4" = {
#         cidr_range = "10.2.0.0/16"
# }

# nat_ip_name = {
#     "us-central1" = "us-central1-nat-ip"
#     "us-east4" = "us-east4-nat-ip"
# }


# router_name ={
#     "us-central1" = "us-central1-router"
#     "us-east4" = "us-east4-router"
# }




