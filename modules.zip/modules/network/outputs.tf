output "nat_ips" {
  value = {
    for key, ip in google_compute_address.tf-nat-ip : key => ip.address
  }
  description = "Public IP addresses of the NAT gateways"
}

