variable "project_id" {
  description = "Project ID"
    type = string
}

variable "regions" {
  description = "List of regions to create subnets,routers,gateways, static ips"
    type = list(string)
}


variable "vpc_name" {
  description = "Name of the vpc"
    type = string
}

variable "subnet_configs" {
  description = "Configuration for the subnets"
  type=map(object({
    cidr_range = string
  }))
}


variable "nat_ip_name" { # static ips
  description = "Name of the NAT IP"
    type = map(string)
}

variable "router_name" {
  description = "Name of the routers"
    type = map(string)
}

variable "labels" {
  description = "Labels to apply to network resources"
  type        = map(string)
  default     = {}
}