resource "google_redis_instance" "tf_redis_instance" {
  name           = var.redis_instance_name
  #region         = "us-central1"
  project        = var.project_id
  tier           = var.redis_tier #"BASIC"
  memory_size_gb = var.redis_memory_size_gb # 1

  location_id = var.redis_zone
  authorized_network = "projects/${var.project_id}/global/networks/${var.vpc_name}"
  connect_mode       = "PRIVATE_SERVICE_ACCESS"

  redis_version = "REDIS_7_0"

  # auth enabled
  auth_enabled = true

  # TLS Disabled
  transit_encryption_mode = "DISABLED"

  labels = var.labels
} 

