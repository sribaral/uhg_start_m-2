variable "project_id" {
  type = string
}

variable "redis_instance_name" {
  type = string
}

variable "redis_tier" {
  type = string
}


variable "redis_memory_size_gb" {
  type = number
  description = "The memory size of the redis instance in GB."
}

variable "redis_zone" {
  type = string
  description = "The GCP zone to deploy the redis instance in."
}

variable "vpc_name" {
  type = string
  description = "The name of the VPC network to deploy the redis instance in."
}

variable "labels" {
  description = "Labels to apply to Redis resources"
  type        = map(string)
  default     = {}
}