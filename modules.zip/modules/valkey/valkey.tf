# https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/memorystore_instance#argument-reference
resource "google_memorystore_instance" "tf_valkey" {
  provider = google-beta
  location                    = "us-central1"
  instance_id = "basic-instance"
  node_type = "SHARED_CORE_NANO"
  project = var.project_id
  # https://cloud.google.com/memorystore/docs/valkey/instance-node-specification?_gl=1*616zz7*_ga*MzgzMjQyNzY3LjE3MjY2NzMxODc.*_ga_WH2QY8WWF5*MTcyNzA3NTcxMi4xMS4xLjE3MjcwNzU3MjMuNDkuMC4w
  shard_count = 3
  replica_count = 1
  desired_psc_auto_connections {
    network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
    project_id = var.project_id
  }
  depends_on = [ google_network_connectivity_service_connection_policy.default ]
  
}

# Create a service connection policy
resource "google_network_connectivity_service_connection_policy" "default" {
  provider = google-beta
  name          = "my-policy"
  location      = "us-central1"
  service_class = "gcp-memorystore"
  description   = "my basic service connection policy"
  network = "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/global/networks/prod-pcn-shared-vpc"
  psc_config {
    subnetworks = [
      "projects/seyxwevo-gu1w-n2uv-41mp-8wmbkd/regions/us-central1/subnetworks/bh-sc-nonprod-subnet"
    ]
  }
}

variable "project_id" {
  description = "The project ID"
}